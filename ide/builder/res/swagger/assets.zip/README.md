# Swagger UI Launcher
##Datos a configurar

1. Archivos de OpenAPI (Versiones compatibles de OpenApi: 2.0, 3.0)
    Guardar archivos de json o yml de OpenAPI donde fuera necesario (en la carpeta "data", por ejemplo). Identificar posteriormente la url en la configuración de Swagger UI utilizando rutas relativas (e.g. "./data/data1.json")

2. Generar "config.json"
    - Parámetro "url": indicar el path del json o yml de la API (en caso de ser una).
    - Parámetro "urls": array de objetos que siguen el formato { "url": "", "name": "" }, donde "url" indica el path del json o yml y "name" qué nombre indicar en el selector.
    - Parámetro "primary": en caso de utilizar múltiples URLS, indicar en este parámetro el nombre del que poner por defecto (si se omite aparece el primero en la lista).
    - Parámetro "headerText": título que indicar junto al logo.
    - Parámetro "headerColor": color de fondo para el header (puede ser especificado en los formatos admitidos por CSS: rgb, hex, ...).
    - Parámetro "selectorBorderColor": color del border para el selector.

Es obligatorio declarar al menos uno de los parámetos "url" o "urls".

3. Imágenes
    Identificar el logo y el favicon dentro de la carpeta imágenes machacando los archivos existentes ("favicon.png" y "logo.png"). Por defecto el favicon es de 32x32 y el logo de 50x50.


NOTA: En caso de indicar dos entradas de OpenAPI, si estas son iguales el selector no dejará cambiar de una a otra puesto que la información es exactamente la misma.