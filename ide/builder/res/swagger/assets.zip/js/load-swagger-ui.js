$(document).ready(function () {

    var _disableComponent = function () { return function () { return null; } };
    var _disableSelector = function () { return function () { return false; } };

    var _customizeHeader = function (config) {
        if (config.background) {
            $(".topbar").css("background", config.background);
        }

        if (config.title) {
            $(document).attr("title", config.title);
            $(".topbar-wrapper .link span").html(config.title);
        }

        if (config.color) {
            $(".topbar-wrapper .link").css("color", config.color);
        }

        if (!config.urls || config.urls.length < 2) {
            $(".topbar-wrapper .download-url-wrapper").css("cssText", "display: none !important");
        }

        if (config.selectorBorderColor) {
            $("#select").css("border-color", config.selectorBorderColor);
        }
    };

    var CustomizePlugin = function () {
        return {
            wrapComponents: {
                InfoUrl: _disableComponent,
                authorizeBtn: _disableComponent,
                // InfoBasePath: _disableComponent,
            },
            statePlugins: {
                spec: {
                    wrapSelectors: { allowTryItOutFor: _disableSelector }
                }
            }
        }
    };

    $.getJSON("./config.json", function (config) {

        var _url = config.url ? config.url : undefined;
        var _urls = config.urls ? config.urls : undefined;
        var _primary = config.primary ? config.primary : undefined;

        if (!_urls && _url) {
            _urls = [{ "url": _url, "name": "" }]
        }

        var ui = SwaggerUIBundle({
            dom_id: "#swagger-ui",
            urls: _urls,
            "urls.primaryName": _primary,
            deepLinking: true,
            filter: false,
            presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIStandalonePreset
            ],
            plugins: [
                SwaggerUIBundle.plugins.DownloadUrl,
                CustomizePlugin
            ],
            layout: "StandaloneLayout",
            validatorUrl: null
        });

        _customizeHeader(config);

        window.ui = ui;
    });

});