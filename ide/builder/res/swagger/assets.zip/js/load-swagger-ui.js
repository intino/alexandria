window.onload = function () {

    var _disableComponent = function () { return function () { return null; } };
    var _disableSelector = function () { return function () { return false; } };

    var _updateHeaderColor = function (color) {
        if (color) {
            $(".topbar").css("background-color", color);
        }
    };

    var _updateTitle = function (title) {
        if (title) {
            $(".topbar .topbar-wrapper .link span").html(title).css("visibility", "initial");
        }
    };

    var _updateSelectorBorderColor = function(color){
        if (color){
            $("#select").css("border-color", color);
        }
    };

    var CustomizePlugin = function () {
        return {
            wrapComponents: {
                InfoUrl: _disableComponent,
                // InfoBasePath: _disableComponent,
                authorizeBtn: _disableComponent,
            },
            statePlugins: {
                spec: {
                    wrapSelectors: { allowTryItOutFor: _disableSelector }
                }
            }
        }
    };

    $.getJSON('./config.json', function (config) {

        var _url = config.url ? config.url : "";
        var _urls = config.urls ? config.urls : [];
        var _primary = config.primary ? config.primary : "";

        var ui = SwaggerUIBundle({
            dom_id: '#swagger-ui',
            url: _url,
            urls: _urls,
            "urls.primary": _primary,
            deepLinking: true,
            filter: false,
            presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIStandalonePreset
            ],
            plugins: [
                SwaggerUIBundle.plugins.DownloadUrl,
                CustomizePlugin
            ],
            layout: "StandaloneLayout"
        });

        _updateHeaderColor(config.headerColor);
        _updateTitle(config.headerText);
        _updateSelectorBorderColor(config.selectorBorderColor);

        window.ui = ui;
    });

}