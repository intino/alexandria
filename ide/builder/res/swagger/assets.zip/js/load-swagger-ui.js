$(document).ready(function () {

    var _disableComponent = function () { return function () { return null; } };
    var _disableSelector = function () { return function () { return false; } };

    var _updateHeader = function (config) {
        if (config.urls) {
            $(".topbar .topbar-wrapper .download-url-wrapper").css("cssText", "display: inherit !important");
        }
        if (config.color) {
            $(".topbar").css("background-color", config.color);
        }
    };

    var _updateTitle = function (title) {
        if (title) {
            $(".topbar .topbar-wrapper .link span").html(title).css("visibility", "initial");
            $(document).attr("title", title);
        }
    };

    var _updateSelectorBorderColor = function (color) {
        if (color) {
            $("#select").css("border-color", color);
        }
    };

    var CustomizePlugin = function () {
        return {
            wrapComponents: {
                InfoUrl: _disableComponent,
                // InfoBasePath: _disableComponent,
                authorizeBtn: _disableComponent,
            },
            statePlugins: {
                spec: {
                    wrapSelectors: { allowTryItOutFor: _disableSelector }
                }
            }
        }
    };

    $.getJSON('./config.json', function (config) {

        var _url = config.url ? config.url : undefined;
        var _urls = config.urls ? config.urls : undefined;
        var _primary = config.primary ? config.primary : undefined;

        var ui = SwaggerUIBundle({
            dom_id: '#swagger-ui',
            url: _url,
            urls: _urls,
            "urls.primaryName": _primary,
            deepLinking: true,
            filter: false,
            presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIStandalonePreset
            ],
            plugins: [
                SwaggerUIBundle.plugins.DownloadUrl,
                CustomizePlugin
            ],
            layout: "StandaloneLayout"
        });

        _updateHeader(config);
        _updateTitle(config.headerText);
        _updateSelectorBorderColor(config.selectorBorderColor);

        window.ui = ui;
    });

});