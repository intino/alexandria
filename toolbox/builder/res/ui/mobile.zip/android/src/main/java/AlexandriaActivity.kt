package io.intino.alexandria.mobile.android.pages

import androidx.activity.ComponentActivity

abstract class AlexandriaActivity : ComponentActivity() {
    protected abstract var name : String

    fun name() : String {
        return name
    }
}