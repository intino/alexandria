package io.intino.alexandria.mobile.android.pages

import android.content.Context
import android.view.ContextThemeWrapper

class AlexandriaContextThemeWrapper(private var activity : String, base: Context?, themeResId: Int) :
    ContextThemeWrapper(base, themeResId) {

    fun activity() : String {
        return activity
    }
}